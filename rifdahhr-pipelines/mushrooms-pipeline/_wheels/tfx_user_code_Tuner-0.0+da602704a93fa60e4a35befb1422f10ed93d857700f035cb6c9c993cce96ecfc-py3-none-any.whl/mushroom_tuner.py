
import tensorflow as tf
import tensorflow_transform as tft
from tensorflow.keras import layers
from kerastuner import HyperParameters
from tfx.components.trainer.fn_args_utils import FnArgs
import os

LABEL_KEY = "class"
CATEGORICAL_FEATURE_KEYS = [
    "cap-shape", "cap-surface", "cap-color", "bruises", "odor",
    "gill-attachment", "gill-spacing", "gill-size", "gill-color",
    "stalk-shape", "stalk-root", "stalk-surface-above-ring", "stalk-surface-below-ring",
    "stalk-color-above-ring", "stalk-color-below-ring", "veil-type", "veil-color",
    "ring-number", "ring-type", "spore-print-color", "population", "habitat"
]

def transformed_name(key):
    return key + "_xf"

def gzip_reader_fn(filenames):
    return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

def input_fn(file_pattern, tf_transform_output, num_epochs=10, batch_size=64):
    transform_feature_spec = tf_transform_output.transformed_feature_spec().copy()
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transform_feature_spec,
        reader=gzip_reader_fn,
        num_epochs=num_epochs,
        label_key=transformed_name(LABEL_KEY),
        shuffle=True)
    return dataset

def tuner_fn(fn_args):
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

    hp = HyperParameters()

    hp_units_1 = hp.Int("units_1", min_value=16, max_value=128, step=16)
    hp_units_2 = hp.Int("units_2", min_value=16, max_value=128, step=16)
    hp_learning_rate = hp.Choice("learning_rate", [0.001, 0.01, 0.1])

    def build_model(hp):
        inputs = {}
        encoded_inputs = []

        for key in CATEGORICAL_FEATURE_KEYS:
            feat_key = transformed_name(key)
            inputs[feat_key] = tf.keras.Input(shape=(1,), name=feat_key, dtype=tf.int64)
            embed = layers.Embedding(20, 4)(inputs[feat_key])
            flat = layers.Flatten()(embed)
            encoded_inputs.append(flat)

        x = tf.keras.layers.concatenate(encoded_inputs)
        x = layers.Dense(hp_units_1, activation='relu')(x)
        x = layers.Dense(hp_units_2, activation='relu')(x)
        outputs = layers.Dense(1, activation='sigmoid')(x)

        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=hp_learning_rate),
            loss='binary_crossentropy',
            metrics=[tf.keras.metrics.BinaryAccuracy()]
        )
        return model

    return {
        "tuner":
            kerastuner.RandomSearch(
                build_model,
                max_trials=10,
                hyperparameters=hp,
                objective='val_binary_accuracy',
                directory=fn_args.working_dir,
                project_name='mushroom_tuning'),
        "train_dataset_fn":
            lambda: input_fn(fn_args.train_files, tf_transform_output, num_epochs=10),
        "eval_dataset_fn":
            lambda: input_fn(fn_args.eval_files, tf_transform_output, num_epochs=10),
        "fit_kwargs": {
            "steps_per_epoch": 100,
            "validation_steps": 50
        }
    }
